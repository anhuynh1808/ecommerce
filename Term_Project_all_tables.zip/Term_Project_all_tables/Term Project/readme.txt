Database connection parameters are located in 
\app\core\Model.php

