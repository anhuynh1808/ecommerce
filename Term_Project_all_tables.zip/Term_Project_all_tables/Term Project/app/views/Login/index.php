<html>
<head>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
	<script src="/js/bootstrap.js"></script>
	<title>Login</title>
</head>
<body>
<div class="container">
	<h1>Log in</h1>
	<form action="" method="post" class="form-horizontal">
	<div class="form-group">
		<label for="username">UserName:</label>
		<input type="text" class="form-control" name="username" id="username" />
	</div>
	<div class="form-group">
		<label for="password">Password:</label>
		<input type="password" class="form-control" name="password" id="password" />
	</div>
	<div class="form-group">
		<input type="submit" name="action" value="Login" />
	</div>
	</form>
</div>
</body></html>