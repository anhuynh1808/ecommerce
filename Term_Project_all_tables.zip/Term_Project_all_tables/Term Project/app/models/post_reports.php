<?php

class post_reports extends Model
{
	protected $report_id;
	protected $report_reason;
	protected $report_date;
	protected $report_message;
	protected $post_id;
	

	public function __construct($report_reason, $report_date, $report_message, $post_id){
		parent::__construct();

		$this->report_reason = $report_reason;
		$this->report_date = $report_date;
		$this->report_message = $report_message;
		$this->post_id = $post_id;		
	}
}

?>