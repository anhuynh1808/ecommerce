<?php

class pm_requests extends Model
{
	protected $pm_request_id;
	protected $request_sender;
	protected $request_recipient;
	protected $subject;
	protected $status;
	protected $session_date;

	public function __construct($request_sender, $request_recipient, $subject, $status,$session_date ){
		parent::__construct();

		$this->request_sender = $request_sender;
		$this->request_recipient = $request_recipient;
		$this->subject = $subject;
		$this->status = $status;
		$this->session_date = date("Y-m-d");
	}
}

?>