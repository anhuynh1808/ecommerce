<?php

class review_votes extends Model
{
	protected $vote_id;
	protected $review_id;
	protected $user_id;
	protected $vote_type;

	public function __construct($review_id, $user_id, $vote_type){
		parent::__construct();

		$this->review_id = $review_id;
		$this->user_id = $user_id;	
		$this->vote_type = $vote_type;
	}
}

?>
