<?php

class post_votes extends Model 
{
	protected $vote_id;
	protected $post_id;
	protected $user_id;
	

	public function __construct($post_id, $user_id){
		parent::__construct();

		$this->post_id = $post_id;
		$this->user_id = $user_id;
		
	}
}

?>