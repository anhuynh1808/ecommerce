<?php

class following extends Model
{
	protected $following_id;
	protected $follower;
	protected $following;
	protected $following_date;

	public function __construct($follower, $following, $following_date){
		parent::__construct();

		$this->follower = $follower;
		$this->following = $following;
		$this->following_date = date("Y-m-d");
		
	}
}

?>