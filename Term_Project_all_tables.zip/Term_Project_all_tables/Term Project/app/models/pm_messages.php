<?php

class pm_messages extends Model
{
	protected $pm_message_id;
	protected $pm_request_id;
	protected $pm_sender;
	protected $pm_recipient;
	protected $pm_message;
	protected $send_date;

	public function __construct($pm_request_id, $pm_sender, $pm_recipient, $pm_message, $send_date){
		parent::__construct();

		$this->pm_request_id = $pm_request_id;
		$this->pm_sender = $pm_sender;
		$this->pm_recipient = $pm_recipient;
		$this->pm_message = $pm_message;
		$this->send_date = date("Y-m-d");
	}
}

?>