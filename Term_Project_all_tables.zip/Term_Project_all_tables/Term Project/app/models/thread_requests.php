<?php

class thread_requests extends Model
{
	protected $thread_request_id;
	protected $subject_id;
	protected $request_reason;
	protected $request_date;
	protected $thread_id;

	public function __construct($subject_id, $request_reason, $request_date, $thread_id){
		parent::__construct();

		$this->subject_id = $subject_id;
		$this->request_reason = $request_reason;
		$this->request_date = date("Y-m-d");
		$this->thread_id = $thread_id;		
	}
}

?>