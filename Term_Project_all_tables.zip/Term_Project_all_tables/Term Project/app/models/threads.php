<?php

class threads extends Model
{
	protected $thread_id;
	protected $thread_title;
	protected $user_id;
	protected $creation_date;
	protected $subject_id;

	public function __construct($thread_title, $user_id, $creation_date, $subject_id){
		parent::__construct();

		$this->thread_title = $thread_title;
		$this->user_id = $user_id;
		$this->creation_date = date("Y-m-d");
		$this->subject_id = $subject_id;
	}
}

?>