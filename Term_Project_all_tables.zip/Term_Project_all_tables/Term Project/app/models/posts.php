<?php

class posts extends Model 
{
	protected $post_id;
	protected $user_id;
	protected $post_date;
	protected $message;
	protected $thread_id;

	public function __construct($user_id, $post_date, $message, $thread_id){
		parent::__construct();

		$this->user_id = $user_id;
		$this->post_date = date("Y-m-d");		
		$this->message = $message;
		$this->thread_id = $thread_id;		
	}
}

?>