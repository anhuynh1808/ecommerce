<?php

class users extends Model
{
	protected $user_id;
	protected $username;
	protected $email;
	protected $password_hash;
	protected $membership_date;
	protected $greeting;
	protected $img_url; 
	protected $reset_token;
	protected $admin_status;
	protected $admin_status;
	protected $report_strikes;
	protected $score;

	public function __construct($username, $email, $password_hash){
		parent::__construct();

		$this->username = $username;
		$this->email = $email;
		$this->password_hash = $password_hash;
		$this->membership_date = date("Y-m-d");		
	}
}

?>