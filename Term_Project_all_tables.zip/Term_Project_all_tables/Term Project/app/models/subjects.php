<?php

class subjects extends Model
{
	protected $subject_id;
	protected $subject_title;
	protected $user_id;

	public function __construct($subject_title, $user_id){
		parent::__construct();

		$this->subject_title = $subject_title;
		$this->user_id = $user_id;	
	}
}

?>
