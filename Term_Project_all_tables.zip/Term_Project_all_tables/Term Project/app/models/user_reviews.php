<?php

class user_reviews extends Model
{
	protected $review_id;
	protected $review_author;
	protected $reviewed_user;
	protected $review_date;
	protected $review;


	public function __construct($review_author, $reviewed_user, $review_date,$review ){
		parent::__construct();

		$this->review_author = $review_author;	
		$this->reviewed_user = $reviewed_user;	
		$this->review_date = $review_date;	
		$this->review = $review;
	}
}

?>
